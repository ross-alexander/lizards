#include <stdio.h>
#include <stdlib.h>

void main(void)
{
	char s[200];

	fprintf(stdout, "Content-type: text/plain\n\n");
	fscanf(stdin, "%12s", s);
	fprintf(stdout, "%s\n\n", s);


	exit(0);
}